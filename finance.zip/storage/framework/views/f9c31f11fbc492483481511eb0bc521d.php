<footer class="footer mt-3">
    <div class="container">
        <div class="d-flex flex-column flex-sm-row justify-content-between pt-2 pb-1 border-top">
            <p>© <?php echo e(now()->year); ?> <?php echo e(config('app.name')); ?>, Inc. All rights reserved.</p>
            <ul class="list-unstyled d-flex">
                <li class="ms-3">
                    <a class="link-body-emphasis" href="#">
                        <i class="fa-brands fa-twitter"></i>
                    </a>
                </li>
                <li class="ms-3">
                    <a class="link-body-emphasis" href="#">
                        <i class="fa-brands fa-facebook"></i>
                    </a>
                </li>
                <li class="ms-3">
                    <a class="link-body-emphasis" href="#">
                        <i class="fa-brands fa-linkedin"></i>
                    </a>
                </li>
            </ul>
        </div>
    </div>

    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            
        <div class="toast-container position-fixed top-0 end-0 p-3">
            <div id="liveToast" class="toast bg-white" role="alert" aria-live="assertive" aria-atomic="true">
                <div class="toast-header bg-danger text-white">
                    <i class="fa-solid fa-warning me-2"></i>
                    <strong class="me-auto">Error</strong>
                    <small><?php echo e(now()->diffForHumans()); ?></small>
                    <button type="button" class="btn-close text-white" data-bs-dismiss="toast" aria-label="Close"></button>
                </div>
                <div class="toast-body">
                    <p class="text-danger"><?php echo e($error); ?></p>
                </div>
            </div>
        </div>
        
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</footer>
<?php /**PATH C:\Apache24\htdocs\laravel\finance\resources\views/components/footer.blade.php ENDPATH**/ ?>