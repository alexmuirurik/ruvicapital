

<?php $__env->startSection('content'); ?>
    <main class="main">
        <div class="container">
            <div class="row">
                <div class="col">
                    <div class="d-flex justify-content-between">
                        <div class="titld">
                            <h4 class="title">Contracts</h4>
                        </div>
                        <div class="dropdown">
                            <a class="btn <?php echo e($errors->any() ? 'btn-danger' : 'btn-success'); ?>" data-bs-toggle="offcanvas" 
                                data-bs-target="#offcanvasRight" aria-controls="offcanvasRight"href="/withdraw/add-new">
                                Sign a Contract
                            </a>
                        </div>
                    </div>
                    <div class="card mt-3">
                        <div class="card-body px-0 pt-2">
                            <div class="search-box justify-content-end pb-2 px-3 border-bottom">
                                <input type="text" class="form-control ms-auto w-25" placeholder="search">
                            </div>
                            <div class="table-responsive ps">
                                <table class="table table-hover">
                                    <thead class="bg-body-tertiary">
                                        <tr>
                                            <th style="width: 1%;" scope="col">#</th>
                                            <th scope="col">Names</th>
                                            <th scope="col">Email</th>
                                            <th scope="col">Contact</th>
                                            <th scope="col">Amount</th>
                                            <th scope="col">Date</th>
                                            <th style="width: 1%;" scope="col">Status</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $contracts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contract): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($loop->index + 1); ?></td>
                                                <td><?php echo e($contract->names); ?></td>
                                                <td><?php echo e($contract->email); ?></td>
                                                <td><?php echo e($contract->mobile); ?></td>
                                                <td>$<?php echo e($contract->amount); ?></td>
                                                <td><?php echo e($contract->termination_date); ?></td>
                                                <td>
                                                    <?php if($contract->status === 'active_contract'): ?>
                                                        <?php if(request()->user()->user_type === 'super_admin'): ?>
                                                            <?php echo $__env->make('forms.terminate', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                                        <?php else: ?>
                                                            <button class="btn btn-success">Active_Contract</button>
                                                        <?php endif; ?>
                                                    <?php else: ?>
                                                        <button class="btn btn-warning"><?php echo e($contract->status); ?></button>
                                                    <?php endif; ?>
                                                    
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <?php echo $__env->make('forms.contract', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Apache24\htdocs\laravel\finance\resources\views/pages/contract.blade.php ENDPATH**/ ?>