<div class="row">
    <div class="col-md-4">
        <div class="card">
            <div class="card-body">
                <h5 class="title">Monthly Deposit</h5>
                <h3 class="title-main">$<?php echo e($earning?->working_capital ?? '0.00'); ?></h3>
                <p class="index">$<?php echo e(array_sum(json_decode($earning->wc_increments ?? '[0.00]'))); ?> increase</p>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card">
            <div class="card-body">
                <h5 class="title">Today's Earnings</h5>
                <h3 class="title-main">$<?php echo e($earning?->interest_earnings ?? '0.00'); ?></h3>
                <p class="index">$<?php echo e(array_sum((array) json_decode($earning->ie_increments  ?? '[0.00]'))); ?> Yesterday's earning</p>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card">
            <div class="card-body">
                <h5 class="title">Withdrawable Earnings</h5>
                <h3 class="title-main">$<?php echo e(array_sum(json_decode($earning?->wc_increments  ?? '[0.00]') ) + $earning?->interest_earnings); ?></h3>
                <p class="index">$<?php echo e($earning?->interest_earnings ?? '0.00'); ?> increase</p>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\Apache24\htdocs\laravel\finance\resources\views/components/dashnings.blade.php ENDPATH**/ ?>