<form action="<?php echo e(route('withdraw.update', $withdraw->uwithdraw_id)); ?>" method="post" id="withdrawUpdate" onsubmit="confirmButtonClick(event)">
    <?php echo csrf_field(); ?>
    <?php echo method_field('put'); ?>
    <input type="hidden" name="udeposit_id" value="<?php echo e($withdraw->uwithdraw_id); ?>">
    <button type="submit" class="btn badge p-2 btn-danger">
        Mark as Sent
    </button>
</form> <?php /**PATH C:\Apache24\htdocs\laravel\finance\resources\views/forms/disburse.blade.php ENDPATH**/ ?>