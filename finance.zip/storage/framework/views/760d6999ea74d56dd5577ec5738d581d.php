<form action="<?php echo e(route('deposits.update', $deposit->udeposit_id)); ?>" method="post" id="depositUpdate">
    <?php echo csrf_field(); ?>
    <?php echo method_field('put'); ?>
    <input type="hidden" name="udeposit_id" value="<?php echo e($deposit->udeposit_id); ?>">
    <button type="submit" class="btn badge p-2 btn-warning" onclick="confirmButtonClick(e, 'depositUpdate')">
        Approve Deposit
    </button>
</form> <?php /**PATH C:\Apache24\htdocs\laravel\finance\resources\views/forms/earning.blade.php ENDPATH**/ ?>