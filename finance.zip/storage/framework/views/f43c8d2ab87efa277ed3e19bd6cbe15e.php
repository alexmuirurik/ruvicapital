

<?php $__env->startSection('content'); ?>
    <main class="main">
        <div class="container">
            <div class="row">
                <div class="col">
                    <div class="d-flex justify-content-between">
                        <div class="titld">
                            <h4 class="title">Referrals</h4>
                        </div>
                        <div class="dropdown">
                            <a class="btn <?php echo e($errors->any() ? 'btn-danger' : 'btn-success'); ?>" data-bs-toggle="offcanvas" 
                            data-bs-target="#offcanvasRight" aria-controls="offcanvasRight" href="/withdraw/add-new">Copy Referral Link</a>
                        </div>
                    </div>
                    <div class="card mt-3">
                        <div class="card-body px-0 pt-2">
                            <div class="d-flex search-box justify-content-between pb-2 px-3 border-bottom">
                                <input type="text" class="form-control ms-auto w-25" placeholder="search">
                            </div>
                            <div class="table-responsive ps">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th class="border-end">#</th>
                                            <th>Name</th>						
                                            <th>Deposit Status</th>
                                            <th>Deposited Amount</th>
                                            <th>Total Commission</th>
                                            <th>Date Created</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td class="border-end" style="width: 1%"><?php echo e($loop->index + 1); ?></td>
                                                <td>
                                                    <a href="<?php echo e(route('user.show', $user->username)); ?>">
                                                        <img src="<?php echo e($user->profile_img); ?>" class="rounded-circle me-2" alt="Avatar" height="30" width="30"> 
                                                        <?php echo e($user->names); ?>

                                                    </a>
                                                </td>                      
                                                <td><?php echo e($user->user_type); ?></td>
                                                <td>
                                                    <span class="status text-<?php echo e($user->status === 'approved' ? 'success' : 'danger'); ?>">•</span>
                                                    <?php echo e($user->status); ?>

                                                </td>
                                                <td><?php echo e($user->created_at); ?></td>  
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <?php echo $__env->make('forms.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Apache24\htdocs\laravel\finance\resources\views/pages/user.blade.php ENDPATH**/ ?>