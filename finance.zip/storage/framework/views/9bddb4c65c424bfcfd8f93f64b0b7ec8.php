<div class="row">
    <div class="col-xl-4">
        <!-- Profile picture card-->
        <?php echo $__env->make('forms.profile_img', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php if($errors->any()): ?>
            <?php echo $__env->make('forms.password', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
        <?php endif; ?>
        
    </div>
    <div class="col-xl-8">
        <!-- Account details card-->
        <div class="card mb-4">
            <div class="card-header">Account Details</div>
            <div class="card-body">
                <form action="<?php echo e(route('user.update', request()->user()->username)); ?>" method="post" id="updateProfile" onsubmit="confirmButtonClick(event)" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('put'); ?>
                    <div class="row gx-3 mb-3">
                        <!-- Form Row-->
                        <div class="row gx-3 mb-3">
                            <!-- Form Group (first name)-->
                            <div class="col-md-6">
                                <label class="small mb-1" for="inputFirstName">First name</label>
                                <input class="form-control" name="firstname" type="text" value="<?php echo e(request()->user()->firstname); ?>">
                            </div>
                            <!-- Form Group (last name)-->
                            <div class="col-md-6">
                                <label class="small mb-1" for="inputLastName">Last name</label>
                                <input class="form-control" name="lastname" type="text" value="<?php echo e(request()->user()->lastname); ?>">
                            </div>
                        </div>
                        <!-- Form Row-->
                        <div class="mb-3">
                            <label class="small mb-1" for="inputOrgName">Referral Link (the link referrals use to sign up)</label>
                            <input class="form-control" name="referral" type="text" value="<?php echo e(request()->user()->referral_id); ?>">
                        </div>
                        <!-- Form Group (organization name)-->
                        <div class="col-md-6">
                            <label class="small mb-1" for="inputUsername">Username (how admins see you)</label>
                            <input class="form-control" name="username" disabled type="text" value="<?php echo e(request()->user()->username); ?>">
                            <input type="file" id="profile_img_input" name="profile_img" class="d-none">
                        </div>
                        <!-- Form Group (location)-->
                        <div class="col-md-6">
                            <label class="small mb-1" for="inputLocation">User Type</label>
                            <input class="form-control" id="inputLocation" type="text" value="<?php echo e(request()->user()->user_type); ?>" disabled>
                        </div>
                    </div>
                    <!-- Form Group (email address)-->
                    <div class="mb-3">
                        <label class="small mb-1" for="inputEmailAddress">Email address</label>
                        <input class="form-control" name="email" type="email" value="<?php echo e(request()->user()->email); ?>">
                    </div>
                    <!-- Form Row-->
                    <div class="row gx-3 mb-3">
                        <!-- Form Group (phone number)-->
                        <div class="col-md-6">
                            <label class="small mb-1" for="inputBirthday">Full Names</label>
                            <input class="form-control" type="text" name="names" value="<?php echo e(request()->user()->names); ?>">
                        </div>
                        <!-- Form Group (birthday)-->
                        <div class="col-md-6">
                            <label class="small mb-1" for="inputPhone">Phone number</label>
                            <input class="form-control" name="mobile" type="tel" value="<?php echo e(request()->user()->mobile); ?>">
                        </div>
                    </div>
                    <!-- Save changes button-->
                    <div class="d-flex justify-content-between">
                        <form action="<?php echo e(route('profile.show')); ?>" method="post" id="deleteProfile" onsubmit="confirmButtonClick(event)">
                            <?php echo csrf_field(); ?>
                           <button class="btn btn-danger btn-sm" type="submit">Delete Account</button> 
                        </form>
                        
                        <button class="btn btn-primary btn-sm" type="submit">Update Profile</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\Apache24\htdocs\laravel\finance\resources\views/forms/profile.blade.php ENDPATH**/ ?>