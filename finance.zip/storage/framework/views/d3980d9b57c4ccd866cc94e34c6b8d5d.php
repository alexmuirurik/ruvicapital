

<?php $__env->startSection('content'); ?>
    <main class="main">
        <div class="container">
            <div class="row gutters-sm">
                <div class="col-md-4 col-lg-3">
                    <div class="card">
                        <div class="card-img d-flex flex-column align-items-center justify-content-center pt-3 px-5 bg-light">
                            <img src="<?php echo e($user->profile_img); ?>" alt="" class="object-fit-cover rounded-circle" width="200" height="200">
                            <h4 class="mt-2"><?php echo e($user->names); ?></h4>
                            <small class="pb-3"><?php echo e($user->email); ?></small>
                        </div>
                        <div class="ul-body">
                            <ul class="list-group">
                                <li class="list-group-item"><span class="fw-bold">Firstname:</span> <?php echo e($user->firstname); ?></li>
                                <li class="list-group-item"><span class="fw-bold">Lastname:</span> <?php echo e($user->lastname); ?></li>
                                <li class="list-group-item"><span class="fw-bold">Mobile: </span> <?php echo e($user->mobile); ?> </li>
                                <li class="list-group-item"><span class="fw-bold">Role:</span> <?php echo e($user->user_type); ?> </li>
                                <li class="list-group-item"><span class="fw-bold">Status:</span> <?php echo e($user->status); ?> </li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-md-8 col-lg-9">
                    <div class="card">
                        <div class="card-img py-5 px-2 bg-light"></div>
                        <div class="card-body">
                            <h5 class="title">User Logs</h5>
                                <table class="table table-hover ">
                                    <thead>
                                      <tr>
                                        <th scope="col">#</th>
                                        <th scope="col">Ip Address</th>
                                        <th scope="col">Browser</th>
                                        <th scope="col">OS</th>
                                        <th scope="col">Device</th>
                                        <th scope="col">Log Date</th>
                                      </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $userlogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $userlog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($loop->index + 1); ?></td>
                                                <td><?php echo e($userlog->ip_address); ?></td>
                                                <td><?php echo e($userlog->browser); ?></td>
                                                <td><?php echo e($userlog->os); ?></td>
                                                <td><?php echo e($userlog->device); ?></td>
                                                <td><?php echo e($userlog->created_at->diffForHumans()); ?></td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6 justify-content-between gap-2">
                            <div class="card">
                                <div class="card-body">
                                    <div class="d-flex">
                                        <div class="title-box d-flex justify-content-center align-items-center w-50">
                                            <span class="fs-2 text-success fw-bolder"><?php echo e(count($referrals)); ?></span>
                                        </div>
                                        <div class="items-box d-flex flex-column">
                                            <h5>Referrals</h5>
                                            <span>
                                                <?php echo e(now()->format('F')); ?>: $<?php echo e(number_format(array_sum(
                                                    array_filter((array)$referrals, function($referral){ 
                                                        isset($referral['deposit_amount']) ?? $referral['deposit_amount']; 
                                                    })
                                                ), 2)); ?>

                                            </span>
                                            <span>Total: $<?php echo e(number_format(array_sum((array)$referrals), 2)); ?></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="card">
                                <div class="card-body">
                                    <div class="d-flex">
                                        <div class="title-box d-flex justify-content-center align-items-center w-50">
                                            <span class="fs-2 text-danger fw-bolder">0</span>
                                        </div>
                                        <div class="items-box d-flex flex-column">
                                            <h5>Earnings</h5>
                                            <span><?php echo e(now()->format('F')); ?>: $<?php echo e(number_format(array_sum((array)$referrals), 2)); ?></span>
                                            <span>Total: $<?php echo e(number_format(array_sum((array)$referrals), 2)); ?></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 justify-content-between gap-2">
                            <div class="card">
                                <div class="card-body">
                                    <div class="d-flex">
                                        <div class="title-box d-flex justify-content-center align-items-center w-50">
                                            <span class="fs-2 text-warning fw-bolder">0</span>
                                        </div>
                                        <div class="items-box d-flex flex-column">
                                            <h5>Profits</h5>
                                            <span><?php echo e(now()->format('F')); ?>: $<?php echo e(number_format(array_sum((array)$referrals), 2)); ?></span>
                                            <span>Total: $<?php echo e(number_format(array_sum((array)$referrals), 2)); ?></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="card">
                                <div class="card-body">
                                    <div class="d-flex">
                                        <div class="title-box d-flex justify-content-center align-items-center w-50">
                                            <span class="fs-2 text-info fw-bolder">0</span>
                                        </div>
                                        <div class="items-box d-flex flex-column">
                                            <h5>Deposits</h5>
                                            <span><?php echo e(now()->format('F')); ?>: $<?php echo e(number_format(array_sum((array)$referrals), 2)); ?></span>
                                            <span>Total: $<?php echo e(number_format(array_sum((array)$referrals), 2)); ?></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Apache24\htdocs\laravel\finance\resources\views/pages/profile.blade.php ENDPATH**/ ?>