

<?php $__env->startSection('content'); ?>
    <main class="main">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="d-flex justify-content-between">
                        <div class="titld">
                            <h4 class="title">Deposits</h4>
                        </div>
                        <div class="dropdown">
                            <a class="btn <?php echo e($errors->any() ? 'btn-danger' : 'btn-success'); ?>" data-bs-toggle="offcanvas" data-bs-target="#offcanvasRight" 
                                aria-controls="offcanvasRight" href="/deposits">
                                Make a Deposit
                            </a>
                        </div>
                    </div>
                </div>
                <div class="col-12">
                    <div class="card mt-3">
                        <div class="card-body px-0 pt-2">
                            <div class="search-box justify-content-end pb-2 px-3 border-bottom">
                                <?php if($errors->any()): ?>
                                    <div class="alert alert-danger mt-3 position-relative">
                                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <p><?php echo e($error); ?></p>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                <?php endif; ?>
                                <?php if(session('status')): ?>
                                    <div class="alert alert-success">
                                        <?php echo e(session('status')); ?>

                                    </div>
                                <?php endif; ?>
                                <input type="text" class="form-control ms-auto w-25" placeholder="Search Data">
                            </div>
                            <div class="table-responsive ps">
                                <table class="table table-hover">
                                    <thead class="bg-body-tertiary">
                                        <tr>
                                            <th style="width: 1%;" scope="col" class="border-right">#</th>
                                            <th scope="col">Names</th>
                                            <th scope="col">Contact</th>
                                            <th scope="col">Amount</th>
                                            <th scope="col">Increment</th>
                                            <th scope="col">Date</th>
                                            <th class="" style="width: 1%;" scope="col">Status</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        
                                        <?php $__currentLoopData = $deposits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $deposit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td style="width: 1%;" scope="row" class="border-right"><?php echo e($loop->index + 1); ?></td>
                                                <td><?php echo e($deposit->names); ?></td>
                                                <td><?php echo e($deposit->mobile); ?></td>
                                                <td>$<?php echo e(number_format((float)$deposit->amount, 2, '.', '')); ?></td>
                                                <td>$<?php echo e(number_format((float)array_sum(json_decode($deposit->increment)), 2, '.', '')); ?></td>
                                                <td><?php echo e($deposit->created_at); ?></td>
                                                <td style="width: 1%;">
                                                    <?php if($deposit->status !== 'funds_received'): ?>
                                                        <?php if(request()->user()->user_type === 'super_admin'): ?>
                                                            <?php echo $__env->make('forms.earning', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
                                                        <?php else: ?>
                                                            <button class="btn badge p-2 btn-warning">
                                                                Pending Receipt
                                                            </button>
                                                        <?php endif; ?>                                                  
                                                    <?php else: ?>
                                                        <button class="btn badge p-2 btn-success">
                                                            Funds Approved
                                                        </button> 
                                                    <?php endif; ?>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <?php echo $__env->make('forms.deposit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Apache24\htdocs\laravel\finance\resources\views/pages/deposits.blade.php ENDPATH**/ ?>