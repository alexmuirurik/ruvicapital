

<?php $__env->startSection('content'); ?>
    <main class="main">
        <div class="container">
            <?php echo $__env->make('forms.profile', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Apache24\htdocs\laravel\finance\resources\views/pages/setting.blade.php ENDPATH**/ ?>