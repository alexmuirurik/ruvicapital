<form action="<?php echo e(route('contract.update', $contract->udeposit_id)); ?>" method="post" id="depositUpdate" onsubmit="confirmButtonClick(event)">
    <?php echo csrf_field(); ?>
    <?php echo method_field('put'); ?>
    <input type="hidden" name="udeposit_id" value="<?php echo e($contract->udeposit_id); ?>">
    <button type="submit" class="btn badge p-2 btn-danger">
        Terminate Contract
    </button>
</form> <?php /**PATH C:\Apache24\htdocs\laravel\finance\resources\views/forms/terminate.blade.php ENDPATH**/ ?>