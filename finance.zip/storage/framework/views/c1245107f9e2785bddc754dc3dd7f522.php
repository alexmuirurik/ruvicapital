<form action="<?php echo e($router); ?>" method="post">
    <?php echo csrf_field(); ?>
    <button type="submit" class="btn badge p-2 btn-warning">
        <?php echo e($btn_title); ?>

    </button>
</form> <?php /**PATH C:\Apache24\htdocs\laravel\finance\resources\views/forms/loop.blade.php ENDPATH**/ ?>