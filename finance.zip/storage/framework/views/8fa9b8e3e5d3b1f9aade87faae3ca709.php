<!DOCTYPE html>
<html>
<head>
    <title><?php echo e(config('app.name')); ?></title>
</head>
<body>
    <p></p>
</body>
</html><?php /**PATH C:\Apache24\htdocs\laravel\finance\resources\views/layouts/mail.blade.php ENDPATH**/ ?>