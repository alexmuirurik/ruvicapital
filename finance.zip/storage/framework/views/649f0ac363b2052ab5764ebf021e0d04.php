

<?php $__env->startSection('content'); ?>
        
    <main class="main">
        <div class="container-fluid">
            
            <?php echo $__env->make('components.adminnings', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            
            <?php echo $__env->make('components.dashchart', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            

            <?php echo $__env->make('components.dashlist', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        </div>
    </main>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Apache24\htdocs\laravel\finance\resources\views/pages/adminboard.blade.php ENDPATH**/ ?>