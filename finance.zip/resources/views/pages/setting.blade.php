@extends('layouts.app')

@section('content')
    <main class="main">
        <div class="container">
            @include('forms.profile')
        </div>
    </main>
@endsection