<div class="row mt-5 mb-4">
    <div class="col">
        <div class="card">
            <div class="card-body">
                <div id="bar">
                    
                </div> 
            </div>
        </div>
    </div>
</div>
