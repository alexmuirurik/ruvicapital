<div class="row">
    <div class="col-md-6">
        <div class="card">
            <div class="card-body">
                <h5 class="title">Revenue</h5><canvas role="img" height="141" width="282"
                    style="box-sizing: border-box; display: block; height: 141px; width: 282px;"></canvas>
            </div>
        </div>
    </div>
    <div class="col-md-6">
        <div class="card">
            <div class="card-body">
                <h5 class="title">Earnings</h5><canvas role="img" height="141" width="282"
                    style="box-sizing: border-box; display: block; height: 141px; width: 282px;"></canvas>
            </div>
        </div>
    </div>
</div>