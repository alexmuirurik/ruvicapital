@extends('layouts.mail')

@section('content')
    
@endsection