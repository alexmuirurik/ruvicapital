<?php

namespace App\Http\Controllers;

use App\Models\Userlog;
use App\Http\Requests\StoreUserlogRequest;
use App\Http\Requests\UpdateUserlogRequest;

class UserlogController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(StoreUserlogRequest $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(Userlog $userlog)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Userlog $userlog)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(UpdateUserlogRequest $request, Userlog $userlog)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Userlog $userlog)
    {
        //
    }
}
